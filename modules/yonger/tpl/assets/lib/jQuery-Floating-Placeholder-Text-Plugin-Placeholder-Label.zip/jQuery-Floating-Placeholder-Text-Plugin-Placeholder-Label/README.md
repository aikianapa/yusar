jquery-placeholder-label
========================

A placeholder label for input

Demo and Doc: http://fabiorogeriosj.com.br/plugins/jquery-placeholder-label/

[![Screen](/example/demo.gif)](/example/demo.gif)
